figure(1)
clf
subplot(411)
plot(out.tout, out.error_J_inverse(:,1),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("e1(m)")
subplot(412)
plot(out.tout, out.error_J_inverse(:,2),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("e2(m)")
subplot(413)
plot(out.tout, out.error_J_inverse(:,3),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("e3(m)")
subplot(414)
plot(out.tout, out.error_J_inverse(:,4),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("e4(rad)")

figure(2)
clf
subplot(411)
plot(out.tout, out.joint_variables_J_inverse(:,1),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("q1(rad)")
subplot(412)
plot(out.tout, out.joint_variables_J_inverse(:,2),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("q2(rad)")
subplot(413)
plot(out.tout, out.joint_variables_J_inverse(:,3),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("d3(m)")
subplot(414)
plot(out.tout, out.joint_variables_J_inverse(:,4),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("q4(rad)")

