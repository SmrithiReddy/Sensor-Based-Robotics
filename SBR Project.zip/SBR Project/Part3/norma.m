function y = norma(x,w)
z = w-x;
y = norm(z);
end 
