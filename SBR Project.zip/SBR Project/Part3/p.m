function [pe, pe_dot, pe_dot_dot] = p()
t = 0:0.001:4;
p0 =[0;-.80;0];
p1 = [0;-0.80;0.5];
p2 = [0.5;-0.6;0.5];
p3 = [0.8;0;0.5];
p4 = [0.8;0;0];
sf1 = norma(p0,p1);
si1=0;
tf1= 0.6;
ti1 =0;
[s1,s1_dot,s1_dot_dot] = trajectory(sf1,si1,tf1,ti1);
sf2 = norma(p1,p2);
si2=0;
tf2=2.0;
ti2 =0.6-0.2;
[s2,s2_dot,s2_dot_dot] = trajectory(sf2,si2,tf2,ti2);
sf3 = norma(p2,p3);
si3 =0;
tf3 = 3.4;
ti3 = 2-0.2;
[s3,s3_dot,s3_dot_dot]=trajectory(sf3,si3,tf3,ti3);
sf4 = norma(p3,p4);
si4 = 0;
tf4 =4;
ti4 = 3.4-0.2;
[s4,s4_dot,s4_dot_dot]= trajectory(sf4,si4,tf4,ti4);
%figure(1);

for i=1:length(s2)
    pe(:,i) = p0+s1(i)*(p1-p0)/norma(p0,p1)+s2(i)*(p2-p1)/norma(p2,p1)+s3(i)*(p3-p2)/norma(p2,p3)+s4(i)*(p4-p3)/norma(p3,p4);

end
for i=1:length(s2_dot)
    pe_dot(:,i) = s1_dot(i)*(p1-p0)/norma(p0,p1)+s2_dot(i)*(p2-p1)/norma(p1,p2)+ s3_dot(i)*(p3-p2)/norma(p2,p3)+s4_dot(i)*(p4-p3)/norma(p3,p4);

end


for i = 1:length(s2_dot_dot)
    pe_dot_dot(:,i) = s1_dot_dot(i)*(p1-p0)/norma(p0,p1)+s2_dot_dot(i)*(p2-p1)/norma(p1,p2) + s3_dot_dot(i)*(p3-p2)/norma(p2,p3)+s4_dot_dot(i)*(p4-p3)/norma(p3,p4);
end

figure(1)
clf;

plot3(pe(1,:),pe(2,:),pe(3,:));
xlabel("x(m)")
ylabel("y(m)")
zlabel("z(m)")

figure(2)
clf;
subplot(311)
plot(t, pe(1,:),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("x(m)")
subplot(312)
plot(t, pe(2,:),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("y(m)")
subplot(313)
plot(t, pe(3,:),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("z(m)")


figure(3)
clf;
subplot(311)
plot(t, pe_dot(1,:),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("x_d(m/s)")
subplot(312)
plot(t, pe_dot(2,:),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("y_d(m/s)")
subplot(313)
plot(t, pe_dot(3,:),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("z_d(m/s)")


figure(4)
clf;
subplot(311)
plot(t, pe_dot_dot(1,:),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("x_d_d(m/s^2)")
subplot(312)
plot(t, pe_dot_dot(2,:),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("y_d_d(m/s^2)")
subplot(313)
plot(t, pe_dot_dot(3,:),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("z_d_d(m/s^2)")

end