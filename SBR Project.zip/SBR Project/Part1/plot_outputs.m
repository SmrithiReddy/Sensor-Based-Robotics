figure(1)
clf

subplot(411)
plot(out.tout, out.err_pos(:,1),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("e_p_1(m)")
subplot(412)
plot(out.tout, out.err_pos(:,2),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("e_p_2(m)")
subplot(413)
plot(out.tout, out.err_pos(:,3),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("e_p_3(m)")
subplot(414)
plot(out.tout, out.err_pos(:,4),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("e_p_4(rad)")

figure(2)
clf

subplot(411)
plot(out.tout, out.err_vel(:,1),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("e_v_1(m/s)")
subplot(412)
plot(out.tout, out.err_vel(:,2),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("e_v_2(m/s)")
subplot(413)
plot(out.tout, out.err_vel(:,3),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("e_v_3(m/s)")
subplot(414)
plot(out.tout, out.err_vel(:,4),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("e_v_4(rad/s)")

figure(3)
clf
subplot(411)
plot(out.tout, out.q(:,1),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("q_1(rad)")
subplot(412)
plot(out.tout, out.q(:,2),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("q_2(rad)")
subplot(413)
plot(out.tout, out.q(:,3),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("d_3(m)")
subplot(414)
plot(out.tout, out.q(:,4),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("q_4(rad)")

figure(4)
clf
subplot(411)
plot(out.tout, out.q_dot(:,1),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("q_d_o_t_1(rad/s)")
subplot(412)
plot(out.tout, out.q_dot(:,2),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("q_d_o_t_2(rad/s)")
subplot(413)
plot(out.tout, out.q_dot(:,3),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("q_d_o_t_3(m/s)")
subplot(414)
plot(out.tout, out.q_dot(:,4),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("q_d_o_t_4(rad/s)")

figure(5)
clf
subplot(411)
plot(out.tout, out.q_dot_dot(:,1),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("q_d_o_t\__d_o_t_1(rad/s^2)")
subplot(412)
plot(out.tout, out.q_dot_dot(:,2),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("q_d_o_t\__d_o_t_2(rad/s^2)")
subplot(413)
plot(out.tout, out.q_dot_dot(:,3),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("q_d_o_t\__d_o_t_3(m/s^2)")
subplot(414)
plot(out.tout, out.q_dot_dot(:,4),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("q_d_o_t\__d_o_t_4(rad/s^2)")
