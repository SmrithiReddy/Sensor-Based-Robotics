function [J_dot] = jacobian_dot(u)
size = length(u)/2;
q = u(1:size);
q_dot = u(size+1:end);
J_dot = [(-cos(q(1)+q(2))*q_dot(1)-cos(q(1)+q(2))*q_dot(2)-cos(q(1))*q_dot(1))/2 (-cos(q(1)+q(2))*q_dot(1)-cos(q(1)+q(2))*q_dot(2))/2 0 0; (-sin(q(1)+q(2))*q_dot(1)-sin(q(1)+q(2))*q_dot(2)-sin(q(1))*q_dot(1))/2 (-sin(q(1)+q(2))*q_dot(1)-sin(q(1)+q(2))*q_dot(2))/2 0 0; 0 0 0 0; 0 0 0 0];
end

