function [J_inv] = jacobian_inverse(q)


J_inv = inv(jacobian(q));

end
