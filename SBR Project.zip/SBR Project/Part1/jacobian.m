function [J] = jacobian(q)
q1= q(1);
q2= q(2);
q3= q(3);
q4= q(4);
J=[ - sin(q1 + q2)/2 - sin(q1)/2, -sin(q1 + q2)/2,  0,  0;   cos(q1 + q2)/2 + cos(q1)/2,  cos(q1 + q2)/2,  0,  0; 0, 0, -1,  0; 1, 1,  0, 1];

end