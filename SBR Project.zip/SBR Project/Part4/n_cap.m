function [n] = n_cap(u) 
m = length(u)/2;
q(1:m,1) = u(1:m);
q_d(1:m,1) = u(m+1,end);
Fm1 = 0.0001; 
Fm2 = 0.0001;
Fm3 = 0.01;
Fm4 = 0.005;
g = 9.8;
 

C = [ -(45*q_d(2)*sin(q(2)))/8, -(45*sin(q(2))*(q_d(1) + q_d(2)))/8, 0, 0;  (45*q_d(1)*sin(q(2)))/8,  0, 0, 0; 0, 0, 0, 0; 0, 0, 0, 0];
 

F = diag([Fm1 Fm2 Fm3 Fm4]);
G = [  0; 0; -10*g; 0];
n = C*q_d+F*q_d+G;