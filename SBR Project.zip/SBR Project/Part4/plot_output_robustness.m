figure(1)
clf

subplot(411)
plot(out.tout, out.err_q_r(:,1),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("e_1(rad)")
subplot(412)
plot(out.tout, out.err_q_r(:,2),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("e_2(rad)")
subplot(413)
plot(out.tout, out.err_q_r(:,3),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("e_3(m)")
subplot(414)
plot(out.tout, out.err_q_r(:,4),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("e_4(rad)")

figure(2)
clf
title("Error in Positions in Operational Space")
subplot(411)
plot(out.tout, out.err_q_dot_r(:,1),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("e_d_o_t_1(rad/s)")
subplot(412)
plot(out.tout, out.err_q_dot_r(:,2),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("e_d_o_t_2(rad/s)")
subplot(413)
plot(out.tout, out.err_q_dot_r(:,3),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("e_d_o_t_3(m/s)")
subplot(414)
plot(out.tout, out.err_q_dot_r(:,4),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("e_d_o_t_4(rad/s)")

figure(3)
clf
subplot(411)
plot(out.tout, out.q_r(:,1),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("q_1(rad)")
subplot(412)
plot(out.tout, out.q_r(:,2),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("q_2(rad)")
subplot(413)
plot(out.tout, out.q_r(:,3),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("d_3(m)")
subplot(414)
plot(out.tout, out.q_r(:,4),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("q_4(rad)")

figure(4)
clf
subplot(411)
plot(out.tout, out.q_dot_r(:,1),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("q_d_o_t_1(rad/s)")
subplot(412)
plot(out.tout, out.q_dot_r(:,2),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("q_d_o_t_2(rad/s)")
subplot(413)
plot(out.tout, out.q_dot_r(:,3),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("q_d_o_t_3(m/s)")
subplot(414)
plot(out.tout, out.q_dot_r(:,4),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("q_d_o_t_4(rad/s)")

figure(5)
clf
subplot(411)
plot(out.tout, out.q_dot_dot_r(:,1),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("q_d_o_t\__d_o_t_1(rad/s^2)")
subplot(412)
plot(out.tout, out.q_dot_dot_r(:,2),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("q_d_o_t\__d_o_t_2(rad/s^2)")
subplot(413)
plot(out.tout, out.q_dot_dot_r(:,3),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("q_d_o_t\__d_o_t_3(m/s^2)")
subplot(414)
plot(out.tout, out.q_dot_dot_r(:,4),'r','LineWidth', 1);
xlabel("t(s)")
ylabel("q_d_o_t\__d_o_t_4(rad/s^2)")
