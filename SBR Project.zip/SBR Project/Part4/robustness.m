function output=robustness(u)
e1=u(1);
e2=u(2);
e3=u(3);
e4=u(4);
e1_dot=u(5);
e2_dot=u(6);
e3_dot=u(7);
e4_dot=u(8);


eps=0.01;

ro=10;

D=[zeros(4,4) eye(4)]';

Q=eye(8);

zita=[e1 e2 e3 e4 e1_dot e2_dot e3_dot e4_dot]';

z=D'*Q*zita;

norm_z=norm(z);


if norm_z>=eps
    output=ro*z/norm_z;
else
    output=ro*z/eps;
end