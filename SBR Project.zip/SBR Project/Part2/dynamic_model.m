function [q_dot_dot] = dynamic_model(in)

size = length(in)/3;
u= in(1:size);
q = in(size+1:2*size);
q_d = in(2*size+1:3*size);
q_dot_dot = B(q)\(u-n([q;q_d]));

end
